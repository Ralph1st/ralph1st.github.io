#initialisation

import sqlite3
import sys

print("")
print("Version actuelle de python : ")
print(str(sys.version_info))
if sys.version_info < (3, 0):
    print("Attention !\nLa version de python que vous utilisez n'est pas compatible avec certaines des fonctions qui suivent !")
    if bool(input("Arrêter le programme et mettre à jour python ? (1 oui / 0 non)")):
        sys.exit()


print('Connexion à la base de données de la bibliothèque...')
connexion = sqlite3.connect('biblio.sqlite')

print("Récupération d'un curseur...")
c = connexion.cursor()

#definition de fonctions

def EZget(c):
    return(c.fetchall())

def EZprint(c):
    print(c.fetchall())

def EZprint2(c) :
    temp = EZget(c)
    for i in temp :
        print(i)

def get_length(c, table_name):
    c.execute(f"SELECT COUNT(*) FROM {table_name}")
    count = c.fetchone()[0]
    return count

def cherche_livre(c, livre):
    temp = (f"%{livre}%",)
    print("Livres correspondants (titre, id) :")
    c.execute("SELECT nomLivre, idLivre FROM Livres WHERE nomLivre like ?", temp)
    EZprint2(c)

def cherche_auteur(c, auteur):
    temp = (f"%{auteur}%",)
    print("Auteurs correspondants (prénom, nom, id) :")
    c.execute("SELECT prénom, nom, idAuteur FROM Auteurs WHERE nom like ?", temp)
    EZprint2(c)
    c.execute("SELECT prénom, nom, idAuteur FROM Auteurs WHERE prénom like ?", temp)
    EZprint2(c)

def cherche_langue(c, langue):
    temp = (f"%{langue}%",)
    print("Langues correspondantes (langue, id) :")
    c.execute("SELECT langue, code FROM Langues WHERE langue like ?", temp)
    EZprint2(c)

    
    
def select_IDlivre(c, id):
    print("\nTitre:")
    temp = (id,)
    c.execute("SELECT nomLivre FROM Livres WHERE idLivre = ?",temp)
    EZprint2(c)
    print("")
    c.execute("SELECT prénom, nom FROM Auteurs INNER JOIN Livres ON Auteurs.idAuteur = Livres.idAuteur WHERE idLivre = ?", temp) #INNER JOIN ICI
    print("Auteur :")
    EZprint2(c)
    c.execute("SELECT langue FROM Langues INNER JOIN Livres ON code = idLang WHERE idLivre = ?", temp)
    print("Langue :")
    EZprint2(c)
    c.execute("SELECT theme FROM Langues INNER JOIN Livres ON code = idLang WHERE idLivre = ?", temp)
    print("Thème du Livre :")
    EZprint2(c)
    c.execute("SELECT resume FROM Langues INNER JOIN Livres ON code = idLang WHERE idLivre = ?", temp)
    print("Résumé :")
    EZprint2(c)
    c.execute("SELECT datePublication FROM Livres WHERE idLivre = ?",temp)
    print("Date de publication :")
    EZprint2(c)
    c.execute("SELECT nombresDePages FROM Livres WHERE idLivre = ?",temp)
    print("Nombre de pages :")
    EZprint2(c)
    c.execute("SELECT imagesOuNon FROM Livres WHERE idLivre = ?",temp)
    temp2 = EZget(c)
    EZprint2(c)
    if temp2 == [(1,)]:
        print("Livre avec images.")
    else:
        print("Livre sans images.")

def select_IDauteur(c, auteur):
    temp = (auteur,)
    print("Prénom et nom de l'auteur :")
    c.execute("SELECT prénom, nom FROM Auteurs WHERE idAuteur = ?",temp)
    EZprint2(c)
    print("années de naissance et de mort :")
    c.execute("SELECT annéeNaiss, annéeMort FROM Auteurs WHERE idAuteur = ?",temp)
    EZprint2(c)
    print("Biographie :")
    c.execute("SELECT biographie FROM Auteurs WHERE idAuteur = ?",temp)
    EZprint2(c)


def voir_biblio(c):
    print("Titre du livre, ID du livre :")
    c.execute("SELECT DISTINCT nomLivre, idLivre FROM Livres")
    EZprint2(c)
    print("longueur totale : ",get_length(c, "Livres"))

def voir_biblio_langue(c,langue):
    print("Titre du livre, ID du livre :")
    c.execute("SELECT DISTINCT nomLivre, idLivre FROM Livres INNER JOIN Langues ON Livres.idLang = Langues.code WHERE Langues.code = ?", (langue,))
    EZprint2(c)

def voir_auteurs(c):
    print("prénom, nom, ID de l'auteur :")
    c.execute("SELECT DISTINCT prénom, nom, idAuteur FROM Auteurs")
    EZprint2(c)
    print("longueur totale : ",get_length(c, "Auteurs"))

def voir_langues(c):
    print("langue, ID de langue :")
    c.execute("SELECT DISTINCT langue, code FROM Langues")
    EZprint2(c)
    print("longueur totale : ",get_length(c, "Langues"))

#MULTIPLE INNER JOINS

def auteurs_FR(c):
    #MULTIPLE INNER JOINS
    print("prénom, nom, ID de l'auteur, langue, ID de la langue :")
    c.execute("SELECT DISTINCT Auteurs.prénom, Auteurs.nom, Auteurs.idAuteur, Langues.langue, Langues.code FROM Langues INNER JOIN Livres ON Langues.code = Livres.idLang INNER JOIN Auteurs ON Livres.idAuteur = Auteurs.idAuteur WHERE Langues.code = 'FR';")
    EZprint2(c)

def auteurs_ALTER(c):
    #MULTIPLE INNER JOINS
    print("prénom, nom, ID de l'auteur, langue, ID de la langue :")
    c.execute("SELECT DISTINCT Auteurs.prénom, Auteurs.nom, Auteurs.idAuteur, Langues.langue, Langues.code FROM Langues INNER JOIN Livres ON Langues.code = Livres.idLang INNER JOIN Auteurs ON Livres.idAuteur = Auteurs.idAuteur WHERE Langues.code != 'FR';")
    EZprint2(c)

def auteurs_nationalite(c,nationalite):
    # MULTIPLE INNER JOINS
    print("prénom, nom, ID de l'auteur, langue, ID de la langue :")
    c.execute("SELECT DISTINCT Auteurs.prénom, Auteurs.nom, Auteurs.idAuteur, Langues.langue, Langues.code FROM Langues INNER JOIN Livres ON Langues.code = Livres.idLang INNER JOIN Auteurs ON Livres.idAuteur = Auteurs.idAuteur WHERE Langues.langue like ?;", (nationalite,))
    EZprint2(c)

#definition des fonctions principales

def Help_User():
    print("\nvoici les commandes disponibles :", flush=True)

    print("\ncommandes importantes :")
    print("- entrez Help pour obtenir de l'aide")
    print("- entrez Exit pour quitter l'application")

    print("\ncommandes pour récupérer une liste d'éléments d'une table :")
    print("- entrez VoirBiblio pour obtenir une liste de tous les livres dans cette bibliothèque")
    print("- entrez VoirAuteurs pour obtenir une liste de tous les auteurs dont un livre au moins est dans cette bibiothèque")
    print("- entrez VoirLangues pour obtenir une liste des diverses langues (et leurs codes) dans lesquelles ont été écrits les livres de cette bibliothèque")
    print("- entrez VoirBiblioALTER pour obtenir une liste des livres d'une certaine langue")
    print("commandes pour obtenir la liste des auteurs français / étrangers : (MULTIPLE INNER JOINS)")
    print("- entrez AuteursFR pour obtenir la liste des auteurs dont les livres sont en français")
    print("- entrez AuteursALTER pour obtenir la liste des auteurs dont les livres sont dans une langue étrangère", flush=True)
    print("- entrez AuteursQUERY pour obtenir une liste des auteurs dont les livres sont dans la langue que vous souhaitez (ex: espagnol, ou français...)")

    print("\ncommandes pour rechercher un élément à partir d'un mot :")
    print("- entrez RechercheLivre pour rechercher un livre, grace à une chaine de charactères", flush=True)
    print("- entrez RechercheAuteur pour rechercher un auteur, grace à une chaine de charactères")
    print("- entrez RechercheLangue pour vérifier si une langue est disponible, grace à une chaine de charactères", flush=True)
    
    print("\ncommandes pour obtenir une fiche d'informations sur un Livre ou Auteur à partir de son ID :")
    print("- entrez InfoLivre pour obtenir des informations sur un livre, en rentrant son ID")
    print("- entrez InfoAuteur pour obtenir des informations sur un auteur, en rentrant son ID", flush=True)
        


def run_app(c):
    '''
    cette fonction tourne en boucle jusqu'à interruption, et permet de rentrer les commandes voulues
    '''
    exit = False
    print("", flush=True)
    print("Bienvenue sur biblio !")
    print("Entrez Help pour obtenir de l'aide")
    print("Entrez Exit pour quitter l'application", flush=True)
    while exit != True :
        if exit  :
            break
        print("", flush=True)
        cmd = str()
        cmd = str(input("Veuillez entrer une commande :  \n"))
        if cmd == "Exit" or cmd == "exit" or cmd == "c" :
            exit = True
            break
        elif cmd == "Help" or cmd == "help" :
            Help_User()
        elif cmd == "RechercheLivre" :
            livre = str(input("Entrez un  mot-clé du titre \n"))
            cherche_livre(c, livre)
        elif cmd == "RechercheAuteur" :
            auteur = str(input("Entrez un nom ou prénom \n"))
            cherche_auteur(c, auteur)
        elif cmd == "RechercheLangue" :
            langue = str(input("Entrez une langue (ex : espagnol)\n"))
            cherche_langue(c, langue)
        elif cmd == "InfoLivre" :
            livre = int(input("Entrez l'ID d'un livre (nombre entier) \n"))
            if type(livre) == int :
                livre = str(livre)
                select_IDlivre(c, livre)
        elif cmd == "InfoAuteur" :
            auteur = int(input("Entrez l'ID d'un auteur (nombre entier) \n"))
            if type(auteur) == int :
                auteur = str(auteur)
                select_IDauteur(c, auteur)
        elif cmd == "VoirBiblio" :
            voir_biblio(c)
        elif cmd == "VoirAuteurs" :
            voir_auteurs(c)
        elif cmd == "VoirLangues" :
            voir_langues(c)
        elif cmd == "VoirBiblioALTER" :
            langue = input("Entrez le code de la langue des livres que vous souhaitez afficher (ex: ES pour espagnol) : \n")
            voir_biblio_langue(c,langue)
        elif cmd == "AuteursFR" :
            auteurs_FR(c)
        elif cmd == "AuteursALTER" :
            auteurs_ALTER(c)
        elif cmd == "AuteursQUERY" :
            nationalite = input("entrez la langue souhaitée (ex : espagnol) :\n")
            auteurs_nationalite(c,nationalite)
        
        else :
            print("erreur : commande erronée ! \npeut être avez vous fait une faute de frappe, avez vous vérifié la capitalisation de votre commande ?")
            print("entrez la commande Help dans le terminal pour obtenir de l'aide quant aux commandes.", flush=True)
        


print('Début des instructions SQL') #execution de la fonction principale
print("")

run_app(c)

print('Sauvegarde ...') 
connexion.commit() #application des modifications
print('Fin des instructions SQL')

print('Déconnexion ...')
connexion.close() #déconnexion de la BDD, suppression du curseur
print('Déconnecté ! \nFin du programme. Passez une bonne journée ;p')
sys.exit() #fin du programme




#snippets pratiques (à supprimer !) :
#connexion = sqlite3.connect("bibliotheque.db")
#c.executemany