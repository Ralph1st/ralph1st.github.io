Ce projet SQL fonctionne à partir d'une application python qu'il faut lancer dans un terminal,
pour ensuite rentrer des commandes qui correspondent à des requêtes SQL.
Vous pouvez ouvrir la BDD avec DB Brower,
et le fichier python avec VS code.
